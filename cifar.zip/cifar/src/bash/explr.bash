#!/usr/bin/env bash
#SBATCH -A SNIC2020-33-39 -p alvis
#SBATCH -N 1
#SBATCH --gpus-per-node=V100:1
#SBATCH -t 48:00:00
#SBATCH -e error_explr.e
#SBATCH -o output_explr.o
#nvidia-smi

module load GCC/8.3.0 CUDA/10.1.243 OpenMPI/3.1.4 PyTorch/1.6.0-Python-3.7.4 tqdm
module load scipy/1.4.1-Python-3.7.4 torchvision/0.7.0-Python-3.7.4-PyTorch-1.6.0
#beta = 1
CUDA_VISIBLE_DEVICES=0
#print('beta', beta )



#python main_sgd_explr.py --optim-method SGD_Exp_Decay --eta0 0.05 --alpha 0.125  --nesterov --momentum 0 --weight-decay 0.0005 --train-epochs 128 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/CIFAR100 --dataset CIFAR100 --dataroot ./data

#python main_sgd_explr_2.py --optim-method SGD_Const_Decay --eta0 0.05 --alpha 0.125  --nesterov --momentum 0 --weight-decay 0.0005 --train-epochs 128 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/CIFAR100 --dataset CIFAR100 --dataroot ./data

#python main_sgd_explr_3.py --optim-method SGD_Const_Decay --eta0 0.05 --alpha 0.125  --nesterov --momentum 0 --weight-decay 0.0005 --train-epochs 128 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/CIFAR100 --dataset CIFAR100 --dataroot ./data


#python main_sgd_explr_4.py --optim-method SGD_Const_Decay --eta0 0.05 --alpha 0.125  --nesterov --momentum 0 --weight-decay 0.0005 --train-epochs 128 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/CIFAR100 --dataset CIFAR100 --dataroot ./data

#python main_sgd_explr_5.py --optim-method SGD_Const_Decay --eta0 0.05 --alpha 0.125  --nesterov --momentum 0 --weight-decay 0.0005 --train-epochs 128 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/CIFAR100 --dataset CIFAR100 --dataroot ./data

## 1 -- 0.05 0.999953
##### 0.1 --- 0.0005 0.999917 bad 0.1
#python main_mom_explr.py --optim-method SGD_Exp_Decay --eta0 1.0 --alpha 0.999928  --momentum 0.0 --weight-decay 0.0005 --train-epochs 164 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/CIFAR100 --dataset CIFAR100 --dataroot ./data

########## 0.01 ----- 0.0001  0.99989
python main_mom_explr_2.py --optim-method SGD_Exp_Decay --eta0 1.0 --alpha 0.999928 --momentum 0.0 --weight-decay 0.0005 --train-epochs 164 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/CIFAR100 --dataset CIFAR100 --dataroot ./data
################ 0.05 ----- 0.0005  0.999928
python main_mom_explr_3.py --optim-method SGD_Exp_Decay --eta0 1.0 --alpha 0.999928  --momentum 0.0 --weight-decay 0.0005 --train-epochs 164 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/CIFAR100 --dataset CIFAR100 --dataroot ./data

########### 0.05 ---- 0.0005
python main_mom_explr_4.py --optim-method SGD_Exp_Decay --eta0 1.0 --alpha 0.999928 --momentum 0.0 --weight-decay 0.0005 --train-epochs 164 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/CIFAR100 --dataset CIFAR100 --dataroot ./data

############## 0.05 ----0.0001
python main_mom_explr_5.py --optim-method SGD_Exp_Decay --eta0 1.0 --alpha  0.999928  --momentum 0.0 --weight-decay 0.0005 --train-epochs 164 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/CIFAR100 --dataset CIFAR100 --dataroot ./data


