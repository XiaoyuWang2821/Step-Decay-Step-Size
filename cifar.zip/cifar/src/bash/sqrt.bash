#!/usr/bin/env bash
#SBATCH -A SNIC2020-33-39 -p alvis
#SBATCH -N 1
#SBATCH --gpus-per-node=V100:1
#SBATCH -t 48:00:00
#SBATCH -e error_sqrt.e
#SBATCH -o output_sqrt.o
#nvidia-smi

module load GCC/8.3.0 CUDA/10.1.243 OpenMPI/3.1.4 PyTorch/1.6.0-Python-3.7.4 tqdm
module load scipy/1.4.1-Python-3.7.4 torchvision/0.7.0-Python-3.7.4-PyTorch-1.6.0
#beta = 1
CUDA_VISIBLE_DEVICES=0
#print('beta', beta )


#
#python main_sgd_stepdecay.py --optim-method SGD_Const_Decay --eta0 0.1 --alpha 0.125  --nesterov --momentum 0.9 --weight-decay 0.0005 --train-epochs 128 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/CIFAR100 --dataset CIFAR100 --dataroot ./data
#
#python main_sgd_stepdecay_2.py --optim-method SGD_Const_Decay --eta0 0.05 --alpha 0.125  --nesterov --momentum 0.9 --weight-decay 0.0005 --train-epochs 128 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/CIFAR100 --dataset CIFAR100 --dataroot ./data
#
#python main_sgd_stepdecay_3.py --optim-method SGD_Const_Decay --eta0 0.01 --alpha 0.125  --nesterov --momentum 0.9 --weight-decay 0.0005 --train-epochs 128 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/CIFAR100 --dataset CIFAR100 --dataroot ./data
#
#
#python main_sgd_stepdecay_4.py --optim-method SGD_Const_Decay --eta0 0.005 --alpha 0.125  --nesterov --momentum 0.9 --weight-decay 0.0005 --train-epochs 128 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/CIFAR100 --dataset CIFAR100 --dataroot ./data
#
#python main_sgd_stepdecay_5.py --optim-method SGD_Const_Decay --eta0 0.001 --alpha 0.125  --nesterov --momentum 0.9 --weight-decay 0.0005 --train-epochs 128 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/CIFAR100 --dataset CIFAR100 --dataroot ./data
#

#### 0.5 --- 0.001 1.97151
#python main_mom_sqrt.py --optim-method SGD_1sqrt_Decay --eta0 1.0 --alpha 0.075068 --momentum 0.0 --weight-decay 0.0005 --train-epochs 164 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/CIFAR100 --dataset CIFAR100 --dataroot ./data

#######3 0.5 ---- 0.0005 3.94698
#python main_mom_sqrt_2.py --optim-method SGD_1sqrt_Decay --eta0 1.0 --alpha 0.075068 --momentum 0.0 --weight-decay 0.0005 --train-epochs 164 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/CIFAR100 --dataset CIFAR100 --dataroot ./data

############ 0.5 ---- 0.005 0.391142
#python main_mom_sqrt_3.py --optim-method SGD_1sqrt_Decay --eta0 1.0 --alpha 0.075068  --momentum 0.0 --weight-decay 0.0005 --train-epochs 164 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/CIFAR100 --dataset CIFAR100 --dataroot ./data

########## 0.1 --- 0.005 0.075068

#python main_mom_sqrt_4.py --optim-method SGD_1sqrt_Decay --eta0 1.0 --alpha 0.075068 --momentum 0.0 --weight-decay 0.0005 --train-epochs 164 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/CIFAR100 --dataset CIFAR100 --dataroot ./data


######### 0.1 ---- 0.001 0.391142
python main_mom_sqrt_5.py --optim-method SGD_1sqrt_Decay --eta0 1.0 --alpha 0.075068 --momentum 0.0 --weight-decay 0.0005 --train-epochs 164 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/CIFAR100 --dataset CIFAR100 --dataroot ./data



