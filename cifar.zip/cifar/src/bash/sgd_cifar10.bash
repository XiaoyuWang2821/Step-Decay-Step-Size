#!/usr/bin/env bash
#SBATCH -A SNIC2020-33-39 -p alvis
#SBATCH -N 1
#SBATCH --gpus-per-node=V100:1
#SBATCH -t 24:30:00
#SBATCH -e error_file_exp_cosine.e
#SBATCH -o output_file_exp_cosine.o

#nvidia-smi

module load GCC/8.3.0 CUDA/10.1.243 OpenMPI/3.1.4 PyTorch/1.6.0-Python-3.7.4 tqdm
module load scipy/1.4.1-Python-3.7.4 torchvision/0.7.0-Python-3.7.4-PyTorch-1.6.0
#beta = 1
CUDA_VISIBLE_DEVICES=0
#print('beta', beta )


########## 
python main.py --optim-method SGD_Step_Decay --eta0 0.1 --alpha 0.125  --nesterov --momentum 0.9 --weight-decay 0.0001 --train-epochs 50 --batchsize 128 --eval-interval 1 --use-cuda --log-folder ./logs/FashionMNIST --dataset FashionMNIST --dataroot ./data




